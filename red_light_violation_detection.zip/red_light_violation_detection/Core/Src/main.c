/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
//#define DIG_SELECT_PINS GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15  //CBA
#define DIG_SELECT_PORT GPIOB
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
typedef enum {
    GREEN_STATE,
    YELLOW_STATE,
    RED_STATE,
		//GREEN_STATE_WE,
   // YELLOW_STATE_WE,
   // RED_STATE_WE
} TrafficLightState;

const uint16_t segmentPins[7] = {
    DIGA_Pin,  // a - PB4
    DIGB_Pin,  // b - PB9
    DIGC_Pin,  // c - PB8
    DIGD_Pin,  // d - PB6
    DIGE_Pin,  // e - PB7
    DIGF_Pin,  // f - PB3
    DIGG_Pin   // g - PB5
};

const uint8_t SEGMENT_CODES[] = {
    0x3F, // 0: 0011 1111
    0x06, // 1: 0000 0110
    0x5B, // 2: 0101 1011
    0x4F, // 3: 0100 1111
    0x66, // 4: 0110 0110
    0x6D, // 5: 0110 1101
    0x7D, // 6: 0111 1101
    0x07, // 7: 0000 0111
    0x7F, // 8: 0111 1111
    0x6F  // 9: 0110 1111
};

volatile uint32_t timerCounter = 0;    
TrafficLightState currentState = GREEN_STATE;  
const uint32_t GREEN_DURATION = 3000;     
const uint32_t YELLOW_DURATION = 2000;   
const uint32_t RED_DURATION = 5000;
const uint32_t SPARK_DURATION = 500;
uint8_t CS_state = 0;
volatile uint8_t display_bufferNS[]={0,0};
volatile uint8_t display_bufferEW[]={0,0};
static uint32_t InfreStateTimeN = 0;
static uint32_t InfreStateTimeW = 0;
static uint32_t InfreStateTimeE = 0;
static uint32_t InfreStateTimeS = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) 
{
    if (htim->Instance == TIM2) {
        timerCounter++;  
    }
}

void UpdateTrafficLight()  
{
    static uint32_t stateStartTime = 0;
    
    switch (currentState) {
        case GREEN_STATE:
            HAL_GPIO_WritePin(GPIOA, LEDW_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(GPIOB, BEEP_Pin, GPIO_PIN_SET);
						HAL_GPIO_WritePin(GPIOB, LEDE_Pin, GPIO_PIN_RESET);
						HAL_GPIO_WritePin(GPIOB, BEEP_Pin, GPIO_PIN_SET);
				
            HAL_GPIO_WritePin(GPIOA, GREENSN_Pin, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOA, YELLOWSN_Pin, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOA, REDSN_Pin, GPIO_PIN_RESET);
				
            HAL_GPIO_WritePin(GPIOA, GREENEW_Pin, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOB, YELLOWEW_Pin, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOB, REDEW_Pin, GPIO_PIN_SET);
   
            if (timerCounter - stateStartTime >= GREEN_DURATION) {
                currentState = YELLOW_STATE;
                stateStartTime = timerCounter;
            }
						display_bufferNS[0] = ((GREEN_DURATION-(timerCounter - stateStartTime))/1000 + 1)/10;
						display_bufferNS[1] = ((GREEN_DURATION-(timerCounter - stateStartTime))/1000 + 1)%10;
						display_bufferEW[0] = ((RED_DURATION-(timerCounter - stateStartTime))/1000 + 1)/10;
						display_bufferEW[1] = ((RED_DURATION-(timerCounter - stateStartTime))/1000 + 1)%10;
						
						if(InfreStateTimeN != 0 || InfreStateTimeS != 0)
						{
							InfreStateTimeN = 0;
							InfreStateTimeS = 0;
						}
						
						if(InfreStateTimeW != 0)
						{
						
							if(((timerCounter - InfreStateTimeW)/SPARK_DURATION)%2==1)
							{
								HAL_GPIO_WritePin(GPIOA, LEDW_Pin, GPIO_PIN_RESET);
								HAL_GPIO_WritePin(GPIOB, BEEP_Pin, GPIO_PIN_SET);
							}
							else if(((timerCounter - InfreStateTimeW)/SPARK_DURATION)%2==0)
							{
								HAL_GPIO_WritePin(GPIOA, LEDW_Pin, GPIO_PIN_SET);
								HAL_GPIO_WritePin(GPIOB, BEEP_Pin, GPIO_PIN_RESET);
							}
							
							
							if((timerCounter - InfreStateTimeW)==1999)
							{
								InfreStateTimeW = 0;
							}
						}
						
						if(InfreStateTimeE != 0)
						{
						
							if(((timerCounter - InfreStateTimeE)/SPARK_DURATION)%2==1)
							{
								HAL_GPIO_WritePin(GPIOB, LEDE_Pin, GPIO_PIN_RESET);
								HAL_GPIO_WritePin(GPIOB, BEEP_Pin, GPIO_PIN_SET);
							}
							else if(((timerCounter - InfreStateTimeE)/SPARK_DURATION)%2==0)
							{
								HAL_GPIO_WritePin(GPIOB, LEDE_Pin, GPIO_PIN_SET);
								HAL_GPIO_WritePin(GPIOB, BEEP_Pin, GPIO_PIN_RESET);
							}
								
							
							if((timerCounter - InfreStateTimeE)==1999)
							{
								InfreStateTimeE = 0;
							}
						}
            break;
            
        case YELLOW_STATE:
						if(((timerCounter - stateStartTime)/SPARK_DURATION)%2==0)
						{
							HAL_GPIO_WritePin(GPIOA, GREENSN_Pin, GPIO_PIN_RESET);
							HAL_GPIO_WritePin(GPIOA, YELLOWSN_Pin, GPIO_PIN_SET);
							HAL_GPIO_WritePin(GPIOA, REDSN_Pin, GPIO_PIN_RESET);
						}
						else{
							HAL_GPIO_WritePin(GPIOA, GREENSN_Pin, GPIO_PIN_RESET);
							HAL_GPIO_WritePin(GPIOA, YELLOWSN_Pin, GPIO_PIN_RESET);
							HAL_GPIO_WritePin(GPIOA, REDSN_Pin, GPIO_PIN_RESET);
						}
				
						HAL_GPIO_WritePin(GPIOA, GREENEW_Pin, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOB, YELLOWEW_Pin, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOB, REDEW_Pin, GPIO_PIN_SET);
            
            if (timerCounter - stateStartTime >= YELLOW_DURATION) {
                currentState = RED_STATE;
                stateStartTime = timerCounter;
            }
						display_bufferNS[0] = ((YELLOW_DURATION-(timerCounter - stateStartTime))/1000 + 1)/10;
						display_bufferNS[1] = ((YELLOW_DURATION-(timerCounter - stateStartTime))/1000 + 1)%10;
						display_bufferEW[0] = ((YELLOW_DURATION-(timerCounter - stateStartTime))/1000 + 1)/10;
						display_bufferEW[1] = ((YELLOW_DURATION-(timerCounter - stateStartTime))/1000 + 1)%10;
						
						if(InfreStateTimeN != 0 || InfreStateTimeS != 0)
						{
							InfreStateTimeN = 0;
							InfreStateTimeS = 0;
						}
						
						if(InfreStateTimeW != 0)
						{
						
						
							if(((timerCounter - InfreStateTimeW)/SPARK_DURATION)%2==0)
							{
								HAL_GPIO_WritePin(GPIOA, LEDW_Pin, GPIO_PIN_SET);
								HAL_GPIO_WritePin(GPIOB, BEEP_Pin, GPIO_PIN_RESET);
							}
							else if(((timerCounter - InfreStateTimeW)/SPARK_DURATION)%2==1)
							{
								HAL_GPIO_WritePin(GPIOA, LEDW_Pin, GPIO_PIN_RESET);
								HAL_GPIO_WritePin(GPIOB, BEEP_Pin, GPIO_PIN_SET);
							}
								
							if((timerCounter - InfreStateTimeW)==1999)
							{
								InfreStateTimeW = 0;
							}
						}
						
						if(InfreStateTimeE != 0)
						{
						
							if(((timerCounter - InfreStateTimeE)/SPARK_DURATION)%2==1)
							{
								HAL_GPIO_WritePin(GPIOB, LEDE_Pin, GPIO_PIN_RESET);
								HAL_GPIO_WritePin(GPIOB, BEEP_Pin, GPIO_PIN_SET);
							}
							else if(((timerCounter - InfreStateTimeE)/SPARK_DURATION)%2==0)
							{
								HAL_GPIO_WritePin(GPIOB, LEDE_Pin, GPIO_PIN_SET);
								HAL_GPIO_WritePin(GPIOB, BEEP_Pin, GPIO_PIN_RESET);
							}
								
							
							if((timerCounter - InfreStateTimeE)==1999)
							{
								InfreStateTimeE = 0;
							}
						}
						
            break;
            
        case RED_STATE:
 
            HAL_GPIO_WritePin(GPIOA, GREENSN_Pin, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOA, YELLOWSN_Pin, GPIO_PIN_RESET);
            HAL_GPIO_WritePin(GPIOA, REDSN_Pin, GPIO_PIN_SET);
						
						
				
						if (timerCounter - stateStartTime >= GREEN_DURATION) {
							if(((timerCounter - stateStartTime)/SPARK_DURATION)%2==0)
							{
								HAL_GPIO_WritePin(GPIOA, GREENEW_Pin, GPIO_PIN_RESET);
								HAL_GPIO_WritePin(GPIOB, YELLOWEW_Pin, GPIO_PIN_SET);
								HAL_GPIO_WritePin(GPIOB, REDEW_Pin, GPIO_PIN_RESET);
							}
							else
							{
								HAL_GPIO_WritePin(GPIOA, GREENEW_Pin, GPIO_PIN_RESET);
								HAL_GPIO_WritePin(GPIOB, YELLOWEW_Pin, GPIO_PIN_RESET);
								HAL_GPIO_WritePin(GPIOB, REDEW_Pin, GPIO_PIN_RESET);
							}
							display_bufferEW[0] = ((RED_DURATION-(timerCounter - stateStartTime))/1000 + 1)/10;
							display_bufferEW[1] = ((RED_DURATION-(timerCounter - stateStartTime))/1000 + 1)%10;
						}
						else
						{
							HAL_GPIO_WritePin(GPIOA, LEDW_Pin, GPIO_PIN_RESET);
							HAL_GPIO_WritePin(GPIOB, BEEP_Pin, GPIO_PIN_SET);
							HAL_GPIO_WritePin(GPIOB, LEDE_Pin, GPIO_PIN_RESET);
							HAL_GPIO_WritePin(GPIOB, BEEP_Pin, GPIO_PIN_SET);
							
							HAL_GPIO_WritePin(GPIOA, GREENEW_Pin, GPIO_PIN_SET);
							HAL_GPIO_WritePin(GPIOB, YELLOWEW_Pin, GPIO_PIN_RESET);
							HAL_GPIO_WritePin(GPIOB, REDEW_Pin, GPIO_PIN_RESET);
							display_bufferEW[0] = ((GREEN_DURATION-(timerCounter - stateStartTime))/1000 + 1)/10;
							display_bufferEW[1] = ((GREEN_DURATION-(timerCounter - stateStartTime))/1000 + 1)%10;
						}
						
            if (timerCounter - stateStartTime >= RED_DURATION) {
                currentState = GREEN_STATE;
                stateStartTime = timerCounter;
            }
						display_bufferNS[0] = ((RED_DURATION-(timerCounter - stateStartTime))/1000 + 1)/10;
						display_bufferNS[1] = ((RED_DURATION-(timerCounter - stateStartTime))/1000 + 1)%10;
						
						if(InfreStateTimeN != 0)
						{
							if(((timerCounter - InfreStateTimeN)/SPARK_DURATION)%2==0)
							{
								HAL_GPIO_WritePin(GPIOA, LEDN_Pin, GPIO_PIN_SET);
								HAL_GPIO_WritePin(GPIOB, BEEP_Pin, GPIO_PIN_RESET);
							}
							
							else if(((timerCounter - InfreStateTimeN)/SPARK_DURATION)%2==1)
							{
								HAL_GPIO_WritePin(GPIOA, LEDN_Pin, GPIO_PIN_RESET);
								HAL_GPIO_WritePin(GPIOB, BEEP_Pin, GPIO_PIN_SET);
							}
							
							if((timerCounter - InfreStateTimeN)==1999)
							{
								InfreStateTimeN = 0;
							}
						}
						
						if(InfreStateTimeS != 0)
						{
						
							if(((timerCounter - InfreStateTimeS)/SPARK_DURATION)%2==1)
							{
								HAL_GPIO_WritePin(GPIOB, LEDS_Pin, GPIO_PIN_RESET);
								HAL_GPIO_WritePin(GPIOB, BEEP_Pin, GPIO_PIN_SET);
							}
							else if(((timerCounter - InfreStateTimeS)/SPARK_DURATION)%2==0)
							{
								HAL_GPIO_WritePin(GPIOB, LEDS_Pin, GPIO_PIN_SET);
								HAL_GPIO_WritePin(GPIOB, BEEP_Pin, GPIO_PIN_RESET);
							}
								
							
							if((timerCounter - InfreStateTimeS)==1999)
							{
								InfreStateTimeS = 0;
							}
						}
						
						if(InfreStateTimeE != 0 || InfreStateTimeW != 0)
						{
							InfreStateTimeE = 0;
							InfreStateTimeW = 0;
						}
            break;
    }
}

void SetSegment(uint8_t code) { 
    
    for (int i = 0; i < 7; i++) {
        
        GPIO_PinState state = (code & (1 << i)) ? GPIO_PIN_SET : GPIO_PIN_RESET;
        
        HAL_GPIO_WritePin(GPIOB, segmentPins[i], state);
    }
}

void ScanDigitalTube() { 
		GPIO_PinState state1 = (CS_state & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET;
		GPIO_PinState state2 = (CS_state & 0x02) ? GPIO_PIN_SET : GPIO_PIN_RESET;
		GPIO_PinState state3 = (CS_state & 0x04) ? GPIO_PIN_SET : GPIO_PIN_RESET;
		HAL_GPIO_WritePin(GPIOC, CS1_Pin, state1);
		HAL_GPIO_WritePin(GPIOC, CS2_Pin, state2);
		HAL_GPIO_WritePin(GPIOC, CS3_Pin, state3);
		if(CS_state == 0 || CS_state ==4)
		{
			SetSegment(SEGMENT_CODES[display_bufferNS[0]]);
		}
		else if(CS_state == 1 || CS_state ==5)
		{
			SetSegment(SEGMENT_CODES[display_bufferNS[1]]);
		}
		else if(CS_state == 2 || CS_state ==6)
		{
			SetSegment(SEGMENT_CODES[display_bufferEW[0]]);
		}
		else
		{
			SetSegment(SEGMENT_CODES[display_bufferEW[1]]);
		}

		CS_state = (CS_state+1)%8;
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(GPIO_Pin == INFREN_Pin)
	{
		//if(currentState == RED_STATE)
		//{
			InfreStateTimeN = timerCounter;
		//}
	}
	if(GPIO_Pin == INFREW_Pin)
	{
		//if(currentState == RED_STATE)
		//{
			InfreStateTimeW = timerCounter;
		//}
	}
	if(GPIO_Pin == INFRES_Pin)
	{
	//	if(currentState == RED_STATE)
	//	{
			InfreStateTimeS = timerCounter;
		//}
	}
	if(GPIO_Pin == INFREE_Pin)
	{
		//if(currentState == RED_STATE)
	//	{
			InfreStateTimeE = timerCounter;
		//}
	}
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
	static uint32_t lastScan = 0;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
	HAL_TIM_Base_Start_IT(&htim2);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		//HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET);
		UpdateTrafficLight();
		
    if (timerCounter - lastScan >= 2) {
        lastScan = timerCounter;
        ScanDigitalTube();
    }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
